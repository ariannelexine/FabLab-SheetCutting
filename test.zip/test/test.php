<?php
/*
 *   CC BY-NC-AS UTA FabLab 2016-2017
 *   FabApp V 0.9
 */
 //This will import all of the CSS and HTML code nessary to build the basic page
include_once ($_SERVER['DOCUMENT_ROOT'].'/pages/header.php');

/*	
 *	When the user presses the button on this screen the form will first call the javascript function located in the onsubmit.
 *	If TRUE will return that value and will submit the page via the method = "post"
 *	ServerSide - the page will reload and below will test if the those two conditions have been met.
*/
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['BaseBtn']) ){
    //Classically it could be retrieved as $_POST['field1'] key/value pair
    //php will be looking for the names of each field
    $field1 = filter_input(INPUT_POST,'field1');
    $field2 = filter_input(INPUT_POST,'field2');



    //////////////////////Method 2 for Reguar Expressions
    //  This will look for 1 to many digits
    $roleid = filter_input(INPUT_POST,'roleSelect');
    if (preg_match("/^\d+$/", $roleid) == 0){
        //  If you delete or comment out the JS that checks for this I have the serverside script to
        //  double check this field value.  (never trust the user)
        echo "<script> alert('Invalid RoleID $roleid')</script>";
        //I called for an EXIT because this should not have been a reach able error
        exit();
    }


    //////////////////////Method 2 for Reguar Expressions
    //  At this point you need to decide where you want to scrub the user input
    //  You must be aware that they user could have malicious intent, see SQL injection
    //  Here I can already assume that this value must be an integar and it must already
    //  exist in the device_group table.  I will call a static function to verify this.
    $dg_id = filter_input(INPUT_POST,'dg_id');
    //	func() returns true if all conditions are met
    // See line 48 of DeviceGroup.php
    if (DeviceGroup::regexDgID($dg_id)){
        //Call javascript to alert the user
        echo "<script> alert('You selected $dg_id')</script>";

        //  I have found it useful to redirect the user to a new page. If the user navigates 
        //	backwards to this page it will have the POST script still set and this might duplicate the intent of the form.
        //	A non-issue for search forms, but if you are inserting a record this could be problematic.
        header("Location:base.php?variable=$dg_id");
    } else {
        echo "<script> alert('POST SCRIPT - nothing was selected')</script>";
    }
}

/*
 *	I am pulling values from the url, like before you should scrub these values before doing anything with them.
 *	
 */
if ( !empty($_GET['variable'])){
    $dg_id = filter_input(INPUT_GET, "variable");
    if (DeviceGroup::regexDgID($dg_id)){
        $dg = new DeviceGroup($dg_id);
    }
}
?>

<?php
/*
Make sure to have functions_database_modify.php & functions_util.php as well!
*/
include 'functions_database_init_TEMP.php';
$server = 'localhost';
$user = 'root';
$password = '';
$database = 'test_database';

$connection = mysqli_connect($server, $user, $password, $database);
if ($connection->connect_error) {
	exit('Connection failed: ' . $connection->connect_error);
}
initDatabase($connection);

echoTable($connection, 'cutlist');
?>

<title><?php echo $sv['site_name'];?> Base</title>
<div id="page-wrapper">
    <div class="row">
        <div class="col-md-12">
            <h1 class="page-header">Sheet Material Inventory</h1>
        </div>
        <!-- /.col-md-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fas fa-cubes fa-lg"></i> Inventory
                </div>
				<div class="panel-body">
					
				</div>
			</div>
		</div>
	</div>
</div>

<?php
//Standard call for dependencies
include_once ($_SERVER['DOCUMENT_ROOT'].'/pages/footer.php');
?>